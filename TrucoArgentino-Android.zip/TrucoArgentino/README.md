# Truco Argentino (Android)

Proyecto Android nativo en Kotlin. Incluye reparto aleatorio de 3 cartas por jugador desde mazo español de 40, ocultar/mostrar cartas por jugador, marcador configurable a 15 o 30 puntos, opción de flor y reparto de nueva mano.

## Compilar
Abrir en Android Studio o ejecutar `gradle assembleDebug` con Android SDK instalado.
También se puede subir a GitHub y ejecutar la acción **Build Truco APK** desde Actions. El APK queda en Artifacts como `TrucoArgentino-debug`.

## Alcance de esta primera versión
El marcador se actualiza manualmente al terminar cada mano. No automatiza todavía la detección de envido, truco, retruco, vale cuatro ni el cálculo de flor.
