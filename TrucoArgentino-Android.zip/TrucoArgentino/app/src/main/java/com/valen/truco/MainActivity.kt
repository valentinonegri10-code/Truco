package com.valen.truco

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.*

data class Card(val rank: Int, val suit: String) {
    fun label(): String = "${rankName(rank)} de $suit"
    private fun rankName(n: Int) = when(n) { 1 -> "1"; 2 -> "2"; 3 -> "3"; 4 -> "4"; 5 -> "5"; 6 -> "6"; 7 -> "7"; 10 -> "10"; 11 -> "11"; else -> "12" }
}

class MainActivity : Activity() {
    private val navy = Color.rgb(20, 39, 52)
    private val green = Color.rgb(24, 112, 78)
    private val cream = Color.rgb(248, 245, 235)
    private val red = Color.rgb(173, 48, 48)
    private lateinit var root: LinearLayout
    private lateinit var scoreA: TextView
    private lateinit var scoreB: TextView
    private lateinit var cardsA: TextView
    private lateinit var cardsB: TextView
    private lateinit var eyeA: Button
    private lateinit var eyeB: Button
    private lateinit var florSwitch: Switch
    private lateinit var handTitle: TextView
    private var target = 15
    private var flor = false
    private var pointsA = 0
    private var pointsB = 0
    private var hand = 0
    private var deck = listOf<Card>()
    private var handA = listOf<Card>()
    private var handB = listOf<Card>()
    private var showA = false
    private var showB = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setup()
        deal()
    }

    private fun setup() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(cream)
        }
        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(page)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        page.addView(TextView(this).apply {
            text = "TRUCO ARGENTINO"
            textSize = 24f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(navy); gravity = Gravity.CENTER
            setPadding(0, 8, 0, 14)
        })
        page.addView(TextView(this).apply { text = "Partida"; textSize = 16f; typeface = Typeface.DEFAULT_BOLD; setTextColor(navy) })
        val targetRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        targetRow.addView(TextView(this).apply { text = "Jugar a:"; textSize = 16f; setTextColor(navy) })
        val targetSpinner = Spinner(this)
        targetSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("15 puntos", "30 puntos"))
        targetRow.addView(targetSpinner)
        targetSpinner.setSelection(0)
        targetSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                target = if(position == 0) 15 else 30
                updateScores()
            }
        }
        page.addView(targetRow)
        florSwitch = Switch(this).apply { text = "Flor habilitada"; setTextColor(navy); isChecked = false }
        florSwitch.setOnCheckedChangeListener { _, checked -> flor = checked }
        page.addView(florSwitch)

        page.addView(section("MARCADOR"))
        val scoreRow = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(0, 6, 0, 12) }
        scoreA = scoreText("JUGADOR 1\n0")
        scoreB = scoreText("JUGADOR 2\n0")
        scoreRow.addView(scoreA, LinearLayout.LayoutParams(0, -2, 1f))
        scoreRow.addView(scoreB, LinearLayout.LayoutParams(0, -2, 1f))
        page.addView(scoreRow)
        val scoreButtons = LinearLayout(this).apply { gravity = Gravity.CENTER }
        scoreButtons.addView(actionButton("+ puntos J1") { addPoints(1) })
        scoreButtons.addView(actionButton("+ puntos J2") { addPoints(2) })
        page.addView(scoreButtons)
        page.addView(actionButton("Deshacer último ajuste") { undoPoints() })

        handTitle = section("MANO $hand")
        page.addView(handTitle)
        page.addView(playerPanel("JUGADOR 1", true))
        page.addView(playerPanel("JUGADOR 2", false))
        page.addView(actionButton("REPARTIR NUEVA MANO") { deal() }.apply {
            textSize = 17f; setBackgroundColor(green); setTextColor(Color.WHITE)
        })
        page.addView(TextView(this).apply {
            text = "Mazo español de 40 cartas · 3 cartas por jugador"
            textSize = 12f; setTextColor(Color.GRAY); gravity = Gravity.CENTER
            setPadding(0, 12, 0, 8)
        })
    }

    private fun playerPanel(name: String, first: Boolean): LinearLayout {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(12, 12, 12, 12)
            setBackgroundColor(Color.WHITE)
        }
        panel.addView(TextView(this).apply {
            text = name; textSize = 17f; typeface = Typeface.DEFAULT_BOLD; setTextColor(navy)
        })
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val cardText = TextView(this).apply {
            text = "🂠   🂠   🂠"; textSize = 22f; setTextColor(navy)
        }
        if(first) cardsA = cardText else cardsB = cardText
        row.addView(cardText, LinearLayout.LayoutParams(0, -2, 1f))
        val eye = Button(this).apply {
            text = "◉"; textSize = 20f; isAllCaps = false
            setOnClickListener {
                if(first) { showA = !showA; renderCards(true) } else { showB = !showB; renderCards(false) }
            }
        }
        if(first) eyeA = eye else eyeB = eye
        row.addView(eye)
        panel.addView(row)
        val spacer = LinearLayout(this).apply { setPadding(0, 4, 0, 4) }
        panel.addView(spacer)
        val hide = TextView(this).apply {
            text = "Tocá el ojo para ver u ocultar tus cartas."
            textSize = 12f; setTextColor(Color.GRAY)
        }
        panel.addView(hide)
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, 12)
        }
        outer.addView(panel)
        return outer
    }

    private fun deal() {
        deck = buildList {
            listOf("Espada", "Basto", "Oro", "Copa").forEach { s ->
                listOf(1,2,3,4,5,6,7,10,11,12).forEach { n -> add(Card(n,s)) }
            }
        }.shuffled()
        handA = deck.take(3)
        handB = deck.drop(3).take(3)
        showA = false; showB = false
        if(::cardsA.isInitialized) {
            hand++
            renderCards(true); renderCards(false)
            updateHandTitle()
        }
    }

    private fun renderCards(first: Boolean) {
        val visible = if(first) showA else showB
        val cards = if(first) handA else handB
        val view = if(first) cardsA else cardsB
        view.text = if(visible) cards.joinToString("   ·   ") { it.label() } else "🂠     🂠     🂠"
        view.textSize = if(visible) 15f else 24f
    }

    private fun addPoints(player: Int) {
        val options = (1..15).map { "$it punto${if(it == 1) "" else "s"}" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Puntos para Jugador $player")
            .setItems(options) { _, which ->
                val value = which + 1
                if(player == 1) pointsA += value else pointsB += value
                updateScores()
                if(pointsA >= target || pointsB >= target) showWinner()
            }.setNegativeButton("Cancelar", null).show()
    }

    private fun undoPoints() {
        val opts = arrayOf("Jugador 1", "Jugador 2")
        AlertDialog.Builder(this).setTitle("¿A quién descontar?")
            .setItems(opts) { _, which ->
                val input = EditText(this).apply { inputType = 2; hint = "Cantidad"; setText("1") }
                AlertDialog.Builder(this).setTitle("Descontar puntos").setView(input)
                    .setPositiveButton("Aceptar") { _, _ ->
                        val n = (input.text.toString().toIntOrNull() ?: 0).coerceAtLeast(0)
                        if(which == 0) pointsA = (pointsA-n).coerceAtLeast(0) else pointsB = (pointsB-n).coerceAtLeast(0)
                        updateScores()
                    }.setNegativeButton("Cancelar", null).show()
            }.setNegativeButton("Cancelar", null).show()
    }

    private fun updateScores() {
        if(!::scoreA.isInitialized) return
        scoreA.text = "JUGADOR 1\n$pointsA"
        scoreB.text = "JUGADOR 2\n$pointsB"
    }
    private fun showWinner() {
        val winner = if(pointsA >= target) "Jugador 1" else "Jugador 2"
        AlertDialog.Builder(this).setTitle("¡Partida terminada!")
            .setMessage("$winner llegó a $target puntos.")
            .setPositiveButton("Nueva partida") { _, _ -> pointsA=0; pointsB=0; hand=0; updateScores(); deal() }
            .setNegativeButton("Seguir", null).show()
    }
    private fun updateHandTitle() {
        handTitle.text = "MANO $hand"
    }
    private fun section(s: String) = TextView(this).apply {
        text = s; textSize = 13f; typeface = Typeface.DEFAULT_BOLD; setTextColor(green)
        setPadding(0, 14, 0, 6)
    }
    private fun scoreText(s: String) = TextView(this).apply {
        text = s; textSize = 22f; typeface = Typeface.DEFAULT_BOLD
        setTextColor(navy); gravity = Gravity.CENTER
    }
    private fun actionButton(s: String, action: () -> Unit) = Button(this).apply {
        text = s; isAllCaps = false; setOnClickListener { action() }
    }
}
